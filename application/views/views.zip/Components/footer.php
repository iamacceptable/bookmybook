<footer class="footer">
  <div class="d-sm-flex justify-content-center justify-content-sm-between">
    <span class="text-muted text-center text-sm-left d-block d-sm-inline-block"><a href="http://www.krishnacollege.ac.in/" target="_blank">Book My Book </a>© 2019 | All rights reserved</span>
    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Made with <i class="ti-heart text-danger "></i> by <a href="http://www.vgeekers.com/" target="_blank">V-Geekers Technologies</a></span>
  </div>
</footer>