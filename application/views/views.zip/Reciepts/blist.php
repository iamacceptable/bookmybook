<div class="row mt-4">
	<div class="col-md-12 grid-margin stretch-card">
	  <div class="card">
	    <div class="card-body">
	      <div class="table-responsive">
	        <table class="table table-hover">
	          <thead>
	            <tr>
	              <th>S.No.</th>
	              <th>Order ID</th>
	              <th>Book Name</th>
	              <th>Author Name</th>
	              <th>Publisher Name</th>
	              <th>Quantity</th>
	              <th>Price</th>
	              <th>Action</th>
	            </tr>
	          </thead>
	          <tbody>
	            <tr>
	              <td>1</td>
	              <td>12425</td>
	              <td>xyz</td>
	              <td>abc</td>
	              <td>abc</td>
	              <td>5</td>
	              <td>₹ 100</td>
	              <td><a href="#" class="text-success mr-3"><i class="ti-write"></i> Bill Slip</a></td>
	            </tr>
	            
	          </tbody>
	        </table>
	      </div>
	    </div>
	  </div>
	</div>
</div>